package pvpki.pvp_ki;

import net.fabricmc.api.ClientModInitializer;

public class Pvp_kiClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}